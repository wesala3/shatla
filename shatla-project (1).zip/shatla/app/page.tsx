'use client'
import { useState, useEffect, useCallback } from 'react'
import { supabase, Store, Plant, PlantStoreLink } from '../lib/supabase'

const ADMIN_PASS = 'shatla2024'

type PlantFull = Plant & {
  plant_store_links: (PlantStoreLink & { stores: Store })[]
}

// ── ICONS ──────────────────────────────────────────────────────────────────
const S = { // shared styles
  input: { width:'100%', padding:'10px 14px', border:'1.5px solid #C9E4CA', borderRadius:10, fontFamily:'Cairo,sans-serif', fontSize:'0.9rem', direction:'rtl' as const, outline:'none', color:'#4A3728', background:'#fff' } as React.CSSProperties,
  label: { fontSize:'0.78rem', fontWeight:700, color:'#4A3728', display:'block', marginBottom:4 } as React.CSSProperties,
  saveBtn: { padding:'10px 20px', background:'#2D6A4F', color:'#fff', border:'none', borderRadius:12, fontFamily:'Cairo,sans-serif', fontWeight:700, fontSize:'0.9rem', cursor:'pointer' } as React.CSSProperties,
  cancelBtn: { padding:'10px 20px', background:'#F3F4F6', color:'#6B7280', border:'none', borderRadius:12, fontFamily:'Cairo,sans-serif', fontWeight:700, fontSize:'0.9rem', cursor:'pointer' } as React.CSSProperties,
}

// ══════════════════════════════════════════════════════════════════════════
// USER SEARCH
// ══════════════════════════════════════════════════════════════════════════
function UserTab() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<PlantFull[] | null>(null)
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState<string | null>(null)

  const chips = ['ورد 🌹','ياسمين 🌸','صبار 🌵','فيكس 🌳','نخيل 🌴','لافندر 💜']

  async function doSearch(q?: string) {
    const term = (q ?? query).trim()
    if (!term) return
    setLoading(true)
    const { data } = await supabase
      .from('plants')
      .select('*, plant_store_links(*, stores(*))')
      .or(`name_ar.ilike.%${term}%,name_en.ilike.%${term}%`)
    setResults((data as PlantFull[]) ?? [])
    setLoading(false)
  }

  function copyPhone(phone: string, key: string) {
    navigator.clipboard.writeText(phone).then(() => {
      setCopied(key)
      setTimeout(() => setCopied(null), 2000)
    })
  }

  return (
    <div style={{ maxWidth:560, margin:'0 auto', padding:'0 16px 60px' }}>
      {/* Hero */}
      <div style={{ textAlign:'center', padding:'32px 0 24px' }}>
        <div style={{ fontSize:48 }}>🌿</div>
        <h1 style={{ fontSize:'1.8rem', fontWeight:900, color:'#2D6A4F', margin:0 }}>شتلة</h1>
        <p style={{ color:'#6B7280', fontSize:'0.9rem', marginTop:4 }}>ابحث عن نبتتك — سعر، محل، ورقم هاتف</p>
      </div>

      {/* Search */}
      <div style={{ display:'flex', gap:10, marginBottom:14 }}>
        <input
          value={query} onChange={e => setQuery(e.target.value)}
          onKeyDown={e => e.key==='Enter' && doSearch()}
          placeholder="اكتب اسم النبتة..."
          style={{ flex:1, padding:'13px 16px', border:'2px solid #C9E4CA', borderRadius:14, fontFamily:'Cairo,sans-serif', fontSize:'1rem', background:'#fff', outline:'none', direction:'rtl', color:'#4A3728' }}
        />
        <button onClick={() => doSearch()} disabled={loading}
          style={{ padding:'13px 20px', background:loading?'#aaa':'#2D6A4F', color:'#fff', border:'none', borderRadius:14, fontFamily:'Cairo,sans-serif', fontSize:'0.95rem', fontWeight:700, cursor:loading?'not-allowed':'pointer' }}>
          {loading ? '...' : '🔍 ابحث'}
        </button>
      </div>

      {/* Chips */}
      <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom:24 }}>
        {chips.map(t => {
          const label = t.split(' ')[0]
          return <button key={t} onClick={() => { setQuery(label); doSearch(label) }}
            style={{ background:'#D8F3DC', color:'#2D6A4F', border:'1px solid #C9E4CA', padding:'5px 14px', borderRadius:20, fontSize:'0.85rem', fontWeight:700, cursor:'pointer', fontFamily:'Cairo,sans-serif' }}>{t}</button>
        })}
      </div>

      {/* Loading */}
      {loading && <div style={{ textAlign:'center', padding:48 }}><div className="spinner"/><p style={{ color:'#6B7280' }}>جاري البحث...</p></div>}

      {/* No results */}
      {!loading && results !== null && results.length === 0 && (
        <div style={{ textAlign:'center', padding:48, color:'#6B7280' }}>
          <div style={{ fontSize:40, marginBottom:10 }}>🔍</div>
          <p>ما لقينا نتائج لـ &quot;{query}&quot;</p>
          <p style={{ fontSize:'0.85rem', marginTop:4 }}>جرب اسم ثاني</p>
        </div>
      )}

      {/* Results */}
      {!loading && results && results.map(plant => (
        <div key={plant.id} style={{ marginBottom:28 }}>
          {/* Plant card */}
          <div style={{ background:'#fff', borderRadius:18, padding:'18px 20px', border:'1px solid #C9E4CA', boxShadow:'0 4px 16px rgba(45,106,79,0.1)', display:'flex', gap:14, alignItems:'flex-start', marginBottom:12 }}>
            <span style={{ fontSize:'2.8rem', lineHeight:1 }}>{plant.emoji}</span>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:'1.3rem', fontWeight:900, color:'#2D6A4F' }}>{plant.name_ar}</div>
              <div style={{ fontSize:'0.82rem', color:'#9CA3AF', marginTop:2 }}>{plant.name_en}</div>
              <div style={{ fontSize:'0.88rem', color:'#555', marginTop:8, lineHeight:1.6 }}>{plant.description}</div>
              <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginTop:10 }}>
                {(plant.tags||[]).map(t => <span key={t} style={{ background:'#D8F3DC', color:'#2D6A4F', fontSize:'0.75rem', fontWeight:700, padding:'3px 10px', borderRadius:10 }}>{t}</span>)}
              </div>
            </div>
          </div>

          {/* Price */}
          <div style={{ background:'linear-gradient(135deg,#2D6A4F,#52B788)', color:'#fff', borderRadius:14, padding:'14px 18px', marginBottom:12, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <div>
              <div style={{ fontSize:'0.82rem', opacity:0.8 }}>نطاق السعر التقريبي</div>
              <div style={{ fontSize:'0.75rem', opacity:0.65 }}>{plant.currency}</div>
            </div>
            <div style={{ fontSize:'1.4rem', fontWeight:900 }}>{plant.price_min.toLocaleString()} — {plant.price_max.toLocaleString()}</div>
          </div>

          {/* Care */}
          <div style={{ background:'#fff', border:'1px solid #C9E4CA', borderRadius:14, padding:'14px 18px', marginBottom:12 }}>
            <div style={{ fontSize:'0.78rem', fontWeight:700, color:'#9CA3AF', marginBottom:10 }}>🌱 طريقة العناية</div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              {[['💧','الري',plant.care_water],['☀️','الضوء',plant.care_sun],['🪴','التربة',plant.care_soil],['🌡️','الحرارة',plant.care_temp]].map(([icon,label,val]) => (
                <div key={label} style={{ display:'flex', alignItems:'center', gap:8 }}>
                  <span style={{ fontSize:'1.1rem' }}>{icon}</span>
                  <div>
                    <div style={{ fontSize:'0.72rem', color:'#9CA3AF' }}>{label}</div>
                    <div style={{ fontSize:'0.88rem', fontWeight:700, color:'#4A3728' }}>{val}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Stores */}
          <div style={{ fontSize:'0.78rem', fontWeight:700, color:'#9CA3AF', marginBottom:8 }}>🏪 المحلات المتاحة</div>
          {(plant.plant_store_links||[]).filter(l => l.stores?.active).map(link => {
            const key = `${plant.id}-${link.store_id}`
            return (
              <div key={link.id} style={{ background:'#fff', border:'1px solid #C9E4CA', borderRadius:14, padding:'14px 16px', marginBottom:10, boxShadow:'0 2px 8px rgba(45,106,79,0.08)' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
                  <div style={{ fontWeight:800, fontSize:'1rem', color:'#4A3728' }}>{link.stores?.name}</div>
                  <span style={{ fontSize:'0.72rem', fontWeight:700, padding:'3px 10px', borderRadius:10, background:link.available?'#D8F3DC':'#FFF3CD', color:link.available?'#2D6A4F':'#856404' }}>
                    {link.available ? '✅ متوفر' : '📞 اتصل للتأكد'}
                  </span>
                </div>
                <div style={{ fontSize:'0.83rem', color:'#9CA3AF', marginTop:4 }}>📍 {link.stores?.location}</div>
                {link.note && <div style={{ fontSize:'0.8rem', color:'#aaa', marginTop:4 }}>💬 {link.note}</div>}
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:12, paddingTop:12, borderTop:'1px dashed #C9E4CA' }}>
                  <div style={{ fontSize:'1.1rem', fontWeight:800, color:'#2D6A4F' }}>{link.price.toLocaleString()} {plant.currency}</div>
                  <button onClick={() => copyPhone(link.stores?.phone, key)}
                    style={{ display:'flex', alignItems:'center', gap:6, padding:'8px 14px', background:copied===key?'#2D6A4F':'#D8F3DC', color:copied===key?'#fff':'#2D6A4F', border:`1.5px solid ${copied===key?'#2D6A4F':'#C9E4CA'}`, borderRadius:10, fontFamily:'Cairo,sans-serif', fontSize:'0.88rem', fontWeight:700, cursor:'pointer', direction:'ltr' }}>
                    {copied===key ? '✅ تم النسخ!' : `📋 ${link.stores?.phone}`}
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      ))}
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════
// ADMIN DASHBOARD
// ══════════════════════════════════════════════════════════════════════════
function AdminTab() {
  const [pass, setPass] = useState('')
  const [auth, setAuth] = useState(false)
  const [passErr, setPassErr] = useState(false)
  const [section, setSection] = useState<'stores'|'plants'>('stores')
  const [stores, setStores] = useState<Store[]>([])
  const [plants, setPlants] = useState<PlantFull[]>([])
  const [toast, setToast] = useState<string|null>(null)
  const [storeForm, setStoreForm] = useState<Partial<Store>|null>(null)
  const [plantForm, setPlantForm] = useState<Partial<Plant>|null>(null)
  const [linkForms, setLinkForms] = useState<Record<string,{price:number,available:boolean,note:string}>>({})

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(null), 2500) }

  const loadStores = useCallback(async () => {
    const { data } = await supabase.from('stores').select('*').order('created_at')
    setStores((data as Store[]) ?? [])
  }, [])

  const loadPlants = useCallback(async () => {
    const { data } = await supabase.from('plants').select('*, plant_store_links(*, stores(*))').order('created_at')
    setPlants((data as PlantFull[]) ?? [])
  }, [])

  useEffect(() => { if (auth) { loadStores(); loadPlants() } }, [auth, loadStores, loadPlants])

  function login() {
    if (pass === ADMIN_PASS) { setAuth(true); setPassErr(false) }
    else setPassErr(true)
  }

  // STORE CRUD
  async function saveStore() {
    if (!storeForm) return
    if (storeForm.id) {
      await supabase.from('stores').update(storeForm).eq('id', storeForm.id)
    } else {
      await supabase.from('stores').insert(storeForm)
    }
    loadStores(); setStoreForm(null); showToast('✅ تم حفظ المحل')
  }

  async function deleteStore(id: string) {
    if (!confirm('تحذف هذا المحل؟')) return
    await supabase.from('stores').delete().eq('id', id)
    loadStores(); showToast('🗑 تم الحذف')
  }

  // PLANT CRUD
  async function savePlant() {
    if (!plantForm) return
    let plantId = plantForm.id
    if (plantId) {
      await supabase.from('plants').update({ ...plantForm }).eq('id', plantId)
    } else {
      const { data } = await supabase.from('plants').insert({ ...plantForm }).select().single()
      plantId = (data as Plant)?.id
    }
    // Save links
    if (plantId) {
      await supabase.from('plant_store_links').delete().eq('plant_id', plantId)
      const links = Object.entries(linkForms).map(([storeId, lf]) => ({ plant_id: plantId, store_id: storeId, ...lf }))
      if (links.length > 0) await supabase.from('plant_store_links').insert(links)
    }
    loadPlants(); setPlantForm(null); setLinkForms({}); showToast('✅ تم حفظ النبتة')
  }

  async function deletePlant(id: string) {
    if (!confirm('تحذف هذه النبتة؟')) return
    await supabase.from('plants').delete().eq('id', id)
    loadPlants(); showToast('🗑 تم الحذف')
  }

  function openPlantForm(plant?: PlantFull) {
    if (plant) {
      setPlantForm({ ...plant })
      const lf: Record<string,{price:number,available:boolean,note:string}> = {}
      plant.plant_store_links?.forEach(l => { lf[l.store_id] = { price: l.price, available: l.available, note: l.note } })
      setLinkForms(lf)
    } else {
      setPlantForm({ emoji:'🌿', currency:'جنيه سوداني', tags:[], price_min:0, price_max:0, care_water:'', care_sun:'', care_soil:'', care_temp:'' })
      setLinkForms({})
    }
  }

  if (!auth) return (
    <div style={{ maxWidth:360, margin:'80px auto', padding:24 }}>
      <div style={{ textAlign:'center', marginBottom:28 }}>
        <div style={{ fontSize:40 }}>🔐</div>
        <h2 style={{ fontWeight:900, color:'#2D6A4F', margin:'8px 0 4px' }}>لوحة الإدارة</h2>
        <p style={{ color:'#9CA3AF', fontSize:'0.88rem' }}>أدخل كلمة السر للمتابعة</p>
      </div>
      <input type="password" value={pass} onChange={e => setPass(e.target.value)} onKeyDown={e => e.key==='Enter' && login()} placeholder="كلمة السر"
        style={{ ...S.input, border:`2px solid ${passErr?'#EF4444':'#C9E4CA'}`, marginBottom:10 }} />
      {passErr && <p style={{ color:'#EF4444', fontSize:'0.85rem', marginBottom:8 }}>كلمة السر غلط</p>}
      <button onClick={login} style={{ ...S.saveBtn, width:'100%', padding:14 }}>دخول</button>
      <p style={{ textAlign:'center', fontSize:'0.78rem', color:'#bbb', marginTop:12 }}>كلمة السر: shatla2024</p>
    </div>
  )

  return (
    <div style={{ maxWidth:680, margin:'0 auto', padding:'24px 16px 60px' }}>
      {toast && <div style={{ position:'fixed', top:20, left:'50%', transform:'translateX(-50%)', background:'#2D6A4F', color:'#fff', padding:'10px 24px', borderRadius:30, fontWeight:700, zIndex:999, boxShadow:'0 4px 20px rgba(0,0,0,0.15)' }}>{toast}</div>}

      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:24 }}>
        <div>
          <h2 style={{ fontWeight:900, color:'#2D6A4F', fontSize:'1.3rem', margin:0 }}>⚙️ لوحة الإدارة</h2>
          <p style={{ color:'#9CA3AF', fontSize:'0.82rem', margin:0 }}>{stores.length} محل · {plants.length} نبتة</p>
        </div>
        <button onClick={() => setAuth(false)} style={{ padding:'7px 14px', background:'#FEE2E2', color:'#DC2626', border:'none', borderRadius:10, fontFamily:'Cairo,sans-serif', fontSize:'0.82rem', fontWeight:700, cursor:'pointer' }}>خروج</button>
      </div>

      {/* Section tabs */}
      <div style={{ display:'flex', gap:8, marginBottom:20 }}>
        {[['stores','🏪 المحلات'],['plants','🌿 النباتات']].map(([key,label]) => (
          <button key={key} onClick={() => setSection(key as 'stores'|'plants')}
            style={{ padding:'9px 20px', borderRadius:12, fontFamily:'Cairo,sans-serif', fontWeight:700, fontSize:'0.9rem', cursor:'pointer', background:section===key?'#2D6A4F':'#D8F3DC', color:section===key?'#fff':'#2D6A4F', border:'none' }}>{label}</button>
        ))}
      </div>

      {/* STORES */}
      {section==='stores' && <>
        <button onClick={() => setStoreForm({ active:true })}
          style={{ ...S.saveBtn, display:'flex', alignItems:'center', gap:6, marginBottom:16 }}>+ إضافة محل</button>

        {storeForm && (
          <div style={{ background:'#F0FDF4', border:'2px solid #52B788', borderRadius:16, padding:20, marginBottom:16 }}>
            <h3 style={{ margin:'0 0 14px', color:'#2D6A4F', fontWeight:800 }}>{storeForm.id ? 'تعديل المحل' : 'إضافة محل جديد'}</h3>
            {[['name','اسم المحل'],['location','الموقع التفصيلي'],['phone','رقم الهاتف'],['area','المنطقة']].map(([k,label]) => (
              <div key={k} style={{ marginBottom:10 }}>
                <label style={S.label}>{label}</label>
                <input value={(storeForm as Record<string,string>)[k]||''} onChange={e => setStoreForm({...storeForm,[k]:e.target.value})} style={S.input} />
              </div>
            ))}
            <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:14 }}>
              <input type="checkbox" checked={storeForm.active??true} onChange={e => setStoreForm({...storeForm,active:e.target.checked})} id="activeChk" />
              <label htmlFor="activeChk" style={{ fontWeight:700, fontSize:'0.88rem', cursor:'pointer' }}>المحل نشط (ظاهر للمستخدمين)</label>
            </div>
            <div style={{ display:'flex', gap:8 }}>
              <button onClick={saveStore} style={S.saveBtn}>💾 حفظ</button>
              <button onClick={() => setStoreForm(null)} style={S.cancelBtn}>إلغاء</button>
            </div>
          </div>
        )}

        {stores.map(s => (
          <div key={s.id} style={{ background:'#fff', border:'1px solid #C9E4CA', borderRadius:14, padding:'14px 16px', marginBottom:10, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <div>
              <div style={{ fontWeight:800, color:'#4A3728' }}>{s.name}</div>
              <div style={{ fontSize:'0.82rem', color:'#9CA3AF' }}>📍 {s.location}</div>
              <div style={{ fontSize:'0.82rem', color:'#52B788', direction:'ltr', textAlign:'right' }}>{s.phone}</div>
            </div>
            <div style={{ display:'flex', gap:8, alignItems:'center' }}>
              <span style={{ fontSize:'0.72rem', fontWeight:700, padding:'3px 8px', borderRadius:8, background:s.active?'#D8F3DC':'#F3F4F6', color:s.active?'#2D6A4F':'#9CA3AF' }}>{s.active?'نشط':'مخفي'}</span>
              <button onClick={() => setStoreForm({...s})} style={{ width:32,height:32,background:'#EFF6FF',color:'#3B82F6',border:'none',borderRadius:8,cursor:'pointer',fontSize:'0.8rem' }}>✏️</button>
              <button onClick={() => deleteStore(s.id)} style={{ width:32,height:32,background:'#FEF2F2',color:'#EF4444',border:'none',borderRadius:8,cursor:'pointer',fontSize:'0.8rem' }}>🗑</button>
            </div>
          </div>
        ))}
      </>}

      {/* PLANTS */}
      {section==='plants' && <>
        <button onClick={() => openPlantForm()} style={{ ...S.saveBtn, display:'flex', alignItems:'center', gap:6, marginBottom:16 }}>+ إضافة نبتة</button>

        {plantForm && (
          <div style={{ background:'#F0FDF4', border:'2px solid #52B788', borderRadius:16, padding:20, marginBottom:16 }}>
            <h3 style={{ margin:'0 0 14px', color:'#2D6A4F', fontWeight:800 }}>{plantForm.id?'تعديل نبتة':'إضافة نبتة جديدة'}</h3>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:10 }}>
              <div><label style={S.label}>الاسم العربي</label><input value={plantForm.name_ar||''} onChange={e => setPlantForm({...plantForm,name_ar:e.target.value})} style={S.input}/></div>
              <div><label style={S.label}>الاسم الإنجليزي</label><input value={plantForm.name_en||''} onChange={e => setPlantForm({...plantForm,name_en:e.target.value})} style={S.input}/></div>
            </div>
            <div style={{ marginBottom:10 }}><label style={S.label}>الرمز emoji</label><input value={plantForm.emoji||''} onChange={e => setPlantForm({...plantForm,emoji:e.target.value})} style={{...S.input,width:80}}/></div>
            <div style={{ marginBottom:10 }}><label style={S.label}>الوصف</label><textarea value={plantForm.description||''} onChange={e => setPlantForm({...plantForm,description:e.target.value})} rows={2} style={{...S.input,resize:'vertical'}}/></div>
            <div style={{ marginBottom:10 }}><label style={S.label}>التصنيفات (افصل بفاصلة)</label>
              <input value={(plantForm.tags||[]).join(',')} onChange={e => setPlantForm({...plantForm,tags:e.target.value.split(',').map(t=>t.trim()).filter(Boolean)})} placeholder="داخلي,سهل العناية" style={S.input}/></div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:10 }}>
              <div><label style={S.label}>السعر الأدنى</label><input type="number" value={plantForm.price_min||0} onChange={e => setPlantForm({...plantForm,price_min:+e.target.value})} style={S.input}/></div>
              <div><label style={S.label}>السعر الأعلى</label><input type="number" value={plantForm.price_max||0} onChange={e => setPlantForm({...plantForm,price_max:+e.target.value})} style={S.input}/></div>
            </div>
            <div style={{ background:'#fff', borderRadius:12, padding:14, marginBottom:12 }}>
              <div style={{ fontSize:'0.82rem', fontWeight:800, color:'#2D6A4F', marginBottom:10 }}>🌱 العناية</div>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
                {[['care_water','💧 الري'],['care_sun','☀️ الضوء'],['care_soil','🪴 التربة'],['care_temp','🌡️ الحرارة']].map(([k,label]) => (
                  <div key={k}><label style={S.label}>{label}</label><input value={(plantForm as Record<string,string>)[k]||''} onChange={e => setPlantForm({...plantForm,[k]:e.target.value})} style={S.input}/></div>
                ))}
              </div>
            </div>
            <div style={{ background:'#fff', borderRadius:12, padding:14, marginBottom:14 }}>
              <div style={{ fontSize:'0.82rem', fontWeight:800, color:'#2D6A4F', marginBottom:10 }}>🏪 ربط بالمحلات</div>
              {stores.filter(s=>s.active).map(store => {
                const link = linkForms[store.id]
                return (
                  <div key={store.id} style={{ marginBottom:12 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
                      <input type="checkbox" checked={!!link} onChange={() => {
                        if (link) { const lf={...linkForms}; delete lf[store.id]; setLinkForms(lf) }
                        else setLinkForms({...linkForms,[store.id]:{price:0,available:true,note:''}})
                      }} id={`st-${store.id}`}/>
                      <label htmlFor={`st-${store.id}`} style={{ fontWeight:700, fontSize:'0.88rem', cursor:'pointer' }}>{store.name}</label>
                    </div>
                    {link && (
                      <div style={{ marginRight:24, display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
                        <div><label style={S.label}>السعر</label><input type="number" value={link.price} onChange={e => setLinkForms({...linkForms,[store.id]:{...link,price:+e.target.value}})} style={S.input}/></div>
                        <div style={{ display:'flex', alignItems:'center', gap:6, marginTop:20 }}>
                          <input type="checkbox" checked={link.available} onChange={e => setLinkForms({...linkForms,[store.id]:{...link,available:e.target.checked}})} id={`av-${store.id}`}/>
                          <label htmlFor={`av-${store.id}`} style={{ fontWeight:700, fontSize:'0.82rem', cursor:'pointer' }}>متوفر</label>
                        </div>
                        <div style={{ gridColumn:'1/-1' }}><label style={S.label}>ملاحظة</label><input value={link.note} onChange={e => setLinkForms({...linkForms,[store.id]:{...link,note:e.target.value}})} style={S.input}/></div>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
            <div style={{ display:'flex', gap:8 }}>
              <button onClick={savePlant} style={S.saveBtn}>💾 حفظ النبتة</button>
              <button onClick={() => { setPlantForm(null); setLinkForms({}) }} style={S.cancelBtn}>إلغاء</button>
            </div>
          </div>
        )}

        {plants.map(p => (
          <div key={p.id} style={{ background:'#fff', border:'1px solid #C9E4CA', borderRadius:14, padding:'14px 16px', marginBottom:10 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
              <div style={{ display:'flex', gap:10, alignItems:'center' }}>
                <span style={{ fontSize:'1.8rem' }}>{p.emoji}</span>
                <div>
                  <div style={{ fontWeight:800, color:'#4A3728' }}>{p.name_ar}</div>
                  <div style={{ fontSize:'0.8rem', color:'#9CA3AF' }}>{p.name_en}</div>
                  <div style={{ fontSize:'0.78rem', color:'#52B788', marginTop:2 }}>{p.price_min.toLocaleString()} — {p.price_max.toLocaleString()} {p.currency}</div>
                </div>
              </div>
              <div style={{ display:'flex', gap:8 }}>
                <button onClick={() => openPlantForm(p)} style={{ width:32,height:32,background:'#EFF6FF',color:'#3B82F6',border:'none',borderRadius:8,cursor:'pointer',fontSize:'0.8rem' }}>✏️</button>
                <button onClick={() => deletePlant(p.id)} style={{ width:32,height:32,background:'#FEF2F2',color:'#EF4444',border:'none',borderRadius:8,cursor:'pointer',fontSize:'0.8rem' }}>🗑</button>
              </div>
            </div>
            <div style={{ marginTop:8, display:'flex', gap:6, flexWrap:'wrap' }}>
              {(p.plant_store_links||[]).map(l => l.stores && (
                <span key={l.id} style={{ background:'#F0FDF4', border:'1px solid #C9E4CA', color:'#2D6A4F', fontSize:'0.72rem', fontWeight:700, padding:'2px 8px', borderRadius:8 }}>
                  {l.stores.name} · {l.price.toLocaleString()}
                </span>
              ))}
            </div>
          </div>
        ))}
      </>}
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════
// ROOT
// ══════════════════════════════════════════════════════════════════════════
export default function App() {
  const [tab, setTab] = useState<'user'|'admin'>('user')
  return (
    <div style={{ minHeight:'100vh', background:'#F8FAF5', fontFamily:'Cairo,sans-serif', direction:'rtl' }}>
      <nav style={{ background:'#2D6A4F', display:'flex', justifyContent:'space-between', alignItems:'center', padding:'0 20px', position:'sticky', top:0, zIndex:100, boxShadow:'0 2px 10px rgba(0,0,0,0.15)' }}>
        <div style={{ color:'#fff', fontWeight:900, fontSize:'1.15rem', padding:'14px 0' }}>🌿 شتلة</div>
        <div style={{ display:'flex', gap:4 }}>
          {[['user','🔍 بحث'],['admin','⚙️ إدارة']].map(([key,label]) => (
            <button key={key} onClick={() => setTab(key as 'user'|'admin')}
              style={{ padding:'8px 16px', borderRadius:10, border:'none', fontFamily:'Cairo,sans-serif', fontWeight:700, fontSize:'0.85rem', cursor:'pointer', background:tab===key?'rgba(255,255,255,0.2)':'transparent', color:'#fff' }}>{label}</button>
          ))}
        </div>
      </nav>
      {tab==='user' && <UserTab/>}
      {tab==='admin' && <AdminTab/>}
    </div>
  )
}
